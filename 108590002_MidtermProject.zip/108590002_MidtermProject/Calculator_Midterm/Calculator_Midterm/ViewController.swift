//
//  ViewController.swift
//  Calculator_Midterm
//
//  Created by Lo Chieh on 2022/5/3.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var equalButton: UIButton!
    @IBOutlet weak var decimalButton: UIButton!
    @IBOutlet var numberButtons: [UIButton]!
    @IBOutlet var operateButtons: [UIButton]!
    
    @IBOutlet weak var calcStatement: UILabel!
    @IBOutlet weak var calcResult: UILabel!
    
    var output: Double = 0.0
    var decimal: Bool = false
    var newCalculation: Bool = false
    
    var working: String = "" {
        didSet {
            if((working.contains("+") || working.contains("-") || working.contains("/") || working.contains("*")) && !working.isEmpty) {
                operateButtons[0].setTitle("C", for: UIControl.State.normal)
            }else if(true || working.first == ("-")) {
                operateButtons[0].setTitle("AC", for: UIControl.State.normal)
            }
            updateView(operation: working)
            calcStatement.text = working
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        calcResult.text = "0"
    }
    
    @IBAction func numberButtons(_ sender: UIButton) {
        if working.last == "."{
            decimal = true
        }
        
        if (calcResult.text != nil) {
            if (newCalculation == true){
                calcResult.text = "\(sender.tag)"
                newCalculation = false
            }else {
                if (calcResult.text == "0" || calcResult.text == "+" || calcResult.text == "-" || calcResult.text == "*" || calcResult.text == "/"){
                    calcResult.text = "\(sender.tag)"
                    addToWorkings(value: "\(sender.tag)")
                }else{
                    calcResult.text = calcResult.text! + "\(sender.tag)"
                    addToWorkings(value: "\(sender.tag)")
                }
            }
        }
    }
    
    @IBAction func operationButtons(_ sender: UIButton) {
        let inputText = calcResult.text
        calcResult.text  = ""
        
        if working == "" {
            working = "0"
        }
    
        switch sender.tag {
        case 0:   // AC
            if calcResult.text == "0" {
                working = "0"
            }
            if( working.first == ("-")){
                working.removeAll()
            }
            else if((working.contains("+") || working.contains("-") || working.contains("/") || working.contains("*")) && !working.isEmpty) {
                working.removeLast()
            }else{
                working.removeAll()
            }
          
        case 1:   // +/-
            if let inputText = inputText{
                if inputText == ""{
                    calcResult.text = "-" + inputText
                }else if inputText != "0"{
                    calcResult.text = ""
                }else if inputText.contains("-"){
                    calcResult.text = inputText.replacingOccurrences(of: "-", with: "")
                }
            }
            working +=  "*-1"
            
        case 2:   // %
            working += "/100"
            if let inputText = inputText {
                var outputText = inputText
                if inputText.contains("."){
                    var distance = outputText.distance(from: outputText.startIndex, to: outputText.firstIndex(of: ".")!)
                    while  distance <= 3{
                        outputText = "0" + outputText
                        distance += 1
                    }
                    let decimalIndex = outputText.firstIndex(of: ".")
                    outputText.remove(at: decimalIndex!)
                    outputText.insert(".", at: inputText.index(decimalIndex!, offsetBy: -2))
                }else{
                    while outputText.count < 3{
                        outputText = "0" + outputText
                    }
                    outputText.insert(".", at: outputText.index(outputText.endIndex, offsetBy: -2))
                }
                calcResult.text = formatResult(result: Double(outputText)!)
                working = "\(outputText)"
            }
            
        case 3:   // /
            if lastOperation(operation: working) {
                working.removeLast()
            }
            working += "/"

        case 4:    // *
            if lastOperation(operation: working) {
                working.removeLast()
            }
            working += "*"
            
        case 5:   // -
            if lastOperation(operation: working) {
                working.removeLast()
            }
            working += "-"

        case 6:   // +
            if lastOperation(operation: working) {
                working.removeLast()
            }
            working += "+"
            
        default:
            calcResult.text = "Error!!!"
            break
        }
        decimal = false
    }
    
    @IBAction func decimalButton(_ sender: UIButton) {
        let inputText = calcResult.text
        if let inputText = inputText {
            if !inputText.contains("."){
                decimal = true
                working += "."
                calcResult.text! += "."
            }
        }
    }
    
    @IBAction func equalButton(_ sender: UIButton) {
        if decimal == false{
            working += ".0"
        }
        
        if(validInput()) {
            let checkedWorkingsForPercent = working.replacingOccurrences(of: "%", with: "*0.01")
            let expression = NSExpression(format: checkedWorkingsForPercent)
            let result = expression.expressionValue(with: nil, context: nil) as! Double
            let resultString = formatResult(result: result)
            calcResult.text = resultString
            working = "\(result)"
            if(working == "inf"){
                working = "0"
                calcResult.text! = "0"
            }
            decimal = true
        }else {
            let alert = UIAlertController(
                title: "Invalid Input",
                message: "Calculator unable to do math based on input",
                preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Okay", style: .default))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func formatResult(result: Double) -> String {
        if(result.truncatingRemainder(dividingBy: 1) == 0) {
            return String(format: "%.0f", result)
        }else {
            return String(format: "%.2f", result)
        }
    }
    
    func addToWorkings(value: String) {
        working = working + value
        calcStatement.text = working
    }
    
    func validInput() ->Bool {
        let funcCharIndexes = [Int]()
        var previous: Int = -1
        for index in funcCharIndexes {
            if(index == 0) {
                return false
            }
            if(index == working.count - 1) {
                return false
            }
            if (previous != -1) {
                if(index - previous == 1) {
                    return false
                }
            }
            previous = index
        }
        return true
    }
    
    func updateView(operation:String) {
        if (operation.last == "/") {
            operateButtons[3].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if (operation.last == "*") {
            operateButtons[4].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if (operation.last == "-") {
            operateButtons[5].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if (operation.last == "+") {
            operateButtons[6].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
        else{
            operateButtons[3].backgroundColor = #colorLiteral(red: 0.6806093454, green: 0.9001615047, blue: 0.9013149142, alpha: 1)
            operateButtons[4].backgroundColor = #colorLiteral(red: 0.6806093454, green: 0.9001615047, blue: 0.9013149142, alpha: 1)
            operateButtons[5].backgroundColor = #colorLiteral(red: 0.6806093454, green: 0.9001615047, blue: 0.9013149142, alpha: 1)
            operateButtons[6].backgroundColor = #colorLiteral(red: 0.6806093454, green: 0.9001615047, blue: 0.9013149142, alpha: 1)
        }
    }
    
    func lastOperation(operation:String) -> Bool {
        if (operation.first == ("-")) {
            return true
        }else if (operation.last == "/") {
            return true
        }else if (operation.last == "*") {
            return true
        }else if (operation.last == "-") {
            return true
        }else if (operation.last == "+") {
            return true
        }else {
            return false
        }
    }
}

